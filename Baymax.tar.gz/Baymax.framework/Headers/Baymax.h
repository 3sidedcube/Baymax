//
//  Baymax.h
//  Baymax
//
//  Created by Matthew Cheetham on 08/11/2018.
//  Copyright © 2018 3 SIDED CUBE. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Baymax.
FOUNDATION_EXPORT double BaymaxVersionNumber;

//! Project version string for Baymax.
FOUNDATION_EXPORT const unsigned char BaymaxVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Baymax/PublicHeader.h>


